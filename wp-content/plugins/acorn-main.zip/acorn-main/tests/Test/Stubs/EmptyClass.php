<?php

namespace Roots\Acorn\Tests\Test\Stubs;

class EmptyClass
{

}
