<?php

test('Console');
