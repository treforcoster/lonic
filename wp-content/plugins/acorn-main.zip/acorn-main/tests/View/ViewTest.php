<?php

test('View');
