<?php

namespace Roots\Acorn;

use Illuminate\Support\Facades\Facade as FacadeBase;

/**
 * @deprecated
 */
abstract class Facade extends FacadeBase
{
    //
}
