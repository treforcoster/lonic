<?php

namespace Roots\Acorn;

use Illuminate\Support\ServiceProvider as ServiceProviderBase;

/**
 * @deprecated
 */
abstract class ServiceProvider extends ServiceProviderBase
{
    //
}
