<?php

namespace Roots\Acorn\Assets\Asset;

class SvgAsset extends TextAsset
{
    public function contentType()
    {
        return 'image/svg+xml';
    }
}
