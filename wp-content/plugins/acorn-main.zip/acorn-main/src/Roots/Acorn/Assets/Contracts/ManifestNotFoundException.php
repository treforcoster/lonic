<?php

namespace Roots\Acorn\Assets\Contracts;

use Exception;

class ManifestNotFoundException extends Exception
{
    //
}
